<h1>{{ trans('main.v_e')}}</h1>

{{ trans('main.v_e3')}}:
<a href="{{ route('user.verify', $token) }}">{{ trans('main.v_e2')}}</a>




<h2>------------------</h2>
<p><b>NGO Affairs Bureau</b> <br>
    Prime Minister's Office <br>
    Plot-E-13/B, Agargaon. Sher-e-Bangla Nagar, Dhaka-1207
</p>




