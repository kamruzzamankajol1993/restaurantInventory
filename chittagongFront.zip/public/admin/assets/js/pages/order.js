
$(function () {

  'use strict';
	
		$('#example1').DataTable({
		  'paging'      : true,
		  'lengthChange': false,
		  'searching'   : false,
		  'ordering'    : true,
		  'info'        : true,
		  'autoWidth'   : false
		});
	
	
	
	
}); // End of use strict
