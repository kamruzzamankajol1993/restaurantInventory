<?php
return [
    'm_b'=>'Passport Size photograph and Nationality of Executive Committee members
    Attested copy of identity card',
    'mem_doc'=>'Ngo Member Document ',
    'person_name' =>'Person Name',
    'image' =>'Image',
    'nid_copy' =>'Nid Copy',
    'add_new_nid'=>'Add new NID & Image',
    'nid_and_images'=>'NID & Images',
];

?>
