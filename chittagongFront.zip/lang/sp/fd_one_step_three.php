<?php
return [
    'All_staff_details_information'=>'All staff details information',
    'staff_position'=>'Staff position (Particulars to be submitted in respect of 5 top executives in the following proforma in separate sheets)',
    'staff_position1'=>'Please Add Minimum Two Member',
    'Step_3'=>'Step 3',
    'staff_one' => 'Staff 01',
    'staff_two' => 'Staff 02',
    'staff_three' => 'Staff 03',
    'staff_four' => 'Staff 04',
    'staff_five' => 'Staff 05',
    'name' => 'Name',
    'desi' => 'Designation',
    'address' => 'Address',
    'date_of_joining' => 'Date of appoinment',
    'citizenship' => 'Citizenship (Must clearify, I duel citizenship)',
    's_statement' => 'Present emoluments',
    'detail' => 'Provide details if associated (in the past or at present) with any other Voluntry Organization (s)',
  	'working' => 'Now working at',
    ];


?>
