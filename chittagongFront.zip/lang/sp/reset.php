<?php
return [
    'data'=>'DATA RESET PAGE',
    'tone'=>'Do you want to completely delete NGO registration information?',
    'ttwo'=>'Once you delete the data you can not get back any of data that you previously input.',
    'select'=>'Select',
    'yes'=>'Yes',
    'no'=>'No',
    'delete'=>'Delete Info',

];

?>
