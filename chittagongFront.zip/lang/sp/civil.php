<?php
return [
  
  'adinfo' => 'Administrative information',
  'add' => 'Add',
  'submit' => 'Submit',
  'update'=>'Update',
 
  
    
];


?>