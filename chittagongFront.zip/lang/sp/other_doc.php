<?php
return [
    'm_b'=>'MB',
    'all_doc'=>'All Documents',
    'reg'=>'NGO Document Registration',
    'others_document'=>'Others Document',
    'list_of_authorized_executive_committee'=>'List of authorized executive committee of primary registering authority and attested copy of registration certificate',
    'attested_copy_of_constitution'=>'Attested copy of constitution (approved by primary registration authority)',
    'activity_report_of_the_organization'=>'Activity report of the organization',
    'donors_receipt_attested_by_head_of_institution'=>'Donors Receipt (Attested by Head of Institution)',
    'general_meeting_regarding'=>'Attested copy of the minutes of the general meeting regarding the constitution of the executive committee of the organization (with signed attendance list of the general members present)',
    'add_new_document'=>'Add New Document',
];


?>
