<?php
return [
    '10y'=>'Details of foreign grant management activities in the last 10 (ten) years (project wise summary to be attached)',
    'money'=>'What is your expected Annual Budget (Foreign Currency Or Bangladeshi taka)',
    'copy'=>'If there is/are letter(s) of commitment from prospective donor(s) (copies) thereof',
    'dd'=>'Please give names of organization (s) with address',
    'pp'=>'Project Area (District and Upazila)',
    'des'=>'details may please be enclosed',
    'Field_of_proposed_activities'=>'Field of proposed activities',
    'Step_2'=>'Step 2',
    'Plan_of_Operation' => 'Plan of Operation',
    'Project_District' => 'Project District',
    'Project_Sub_District' => 'Sub District',
    'Source_of_Fund' => 'Source (s) of Fund',
    'Name_of_donor_organization' => 'Name of donor organization',
    'Address_of_donor_organization' => 'Address of donor organization',
    'Letter_of_Commitment_from_Prospective_donor' => 'Letter of Commitment from Prospective donor',
    'What_is_Your_Expected_Annual_Budget_Foreign_Currency_or_Bangladeshi_Taka' => 'What is Your Expected Annual Budget (Foreign Currency or Bangladeshi Taka)',
    'Add_New_Donor_Information'=>'Add New Donor Information',
    ];


?>
