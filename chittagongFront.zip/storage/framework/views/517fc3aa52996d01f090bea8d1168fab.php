
<footer class="main-footer">
    <div class="pull-right d-none d-sm-inline-block">
        <ul class="nav nav-primary nav-dotted nav-dot-separated justify-content-center justify-content-md-end">
            <li class="nav-item">
                <a class="nav-link" href="javascript:void(0)">FAQ</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Need Help?</a>
            </li>
        </ul>
    </div>
    &copy; 2024 <a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e($ins_name); ?></a>. All Rights Reserved.
</footer>
<?php /**PATH F:\project2023\htdocs\chittagongFront\resources\views/admin/include/footer.blade.php ENDPATH**/ ?>