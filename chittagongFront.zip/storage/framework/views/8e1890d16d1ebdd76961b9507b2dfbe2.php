<?php $__env->startSection('title'); ?>
Product List
<?php $__env->stopSection(); ?>



<?php $__env->startSection('body'); ?>
<div class="content-header">
    <div class="d-flex align-items-center">
        <div class="me-auto">
            <h4 class="page-title">Product List</h4>
        </div>

    </div>
</div>

<section class="content">
    <div class="row">
        <div class="col-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">All Product List</h3>
                    <?php echo $__env->make('flash_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <!-- /.box-header -->
                <div class="box-body">

                    <div class="table-responsive">
                        <table id="example5" class="table table-bordered" style="width:100%">
                            <thead>
                            <tr>
                                <th>SL</th>
                                <th>Product Name</th>
                                <th>Selling Price</th>
                                <th>Total Sale</th>
                                <th>Stock</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $productList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$productLists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>01</td>
                                <td>
                                    <div class="d-flex justify-content-center align-items-center">
                                        <img class="table_image_box" src="<?php echo e(asset('/')); ?><?php echo e($productLists->product_image); ?>" alt="">
                                        <span><?php echo e($productLists->product_name); ?></span>
                                    </div>
                                </td>
                                <td>
                                    <?php echo e($productLists->default_price); ?> Taka
                                </td>
                                <td>
                                    0
                                </td>
                                <td>
                                    Stock Type: <span class="badge badge-primary-light"><?php echo e($productLists->product_stock_type); ?></span>
                                    <br>
                                    Stock: <span class="badge badge-primary"><?php echo e($productLists->product_stock_quantity); ?></span>
                                </td>
                                <td>
                                    <select class="form-control available_status" name="" id="">
                                        <option data-id="<?php echo e($productLists->id); ?>" value="Yes" <?php echo e('Yes' == $productLists->available_status ? 'selected':''); ?>>Yes</option>
                                        <option data-id="<?php echo e($productLists->id); ?>"  value="No" <?php echo e('No' == $productLists->available_status ? 'selected':''); ?>>No</option>
                                    </select>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('productList.show',$productLists->id)); ?>" class="text-info me-10" data-bs-toggle="tooltip" data-bs-original-title="View">
                                        <i class="fa fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('productList.edit',$productLists->id)); ?>" class="text-info me-10" data-bs-toggle="tooltip" data-bs-original-title="Edit">
                                        <i class="fa fa-edit"></i>
                                    </a>

                                    <a href="javascript:void(0)" onclick="deleteTag(<?php echo e($productLists->id); ?>)" class="text-danger" data-bs-original-title="Delete" data-bs-toggle="tooltip">
                                        <i class="fa fa-trash"></i>
                                    </a>

                                    <form id="delete-form-<?php echo e($productLists->id); ?>" action="<?php echo e(route('productList.destroy',$productLists->id)); ?>" method="POST" style="display: none;">
                                        <?php echo method_field('DELETE'); ?>
                                                                                          <?php echo csrf_field(); ?>

                                                                                      </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>

<script>
$(document).on('change', '.available_status', function () {

    var status = $(this).find(':selected').val();

    var id =   $(this).find(':selected').data('id')


        $.ajax({
    url: "<?php echo e(route('productStatusUpdate')); ?>",
    method: 'get',
    data: {status:status,id:id},
    beforeSend: function(){
        $('#loader').show()
    },
    complete: function(){
        $('#loader').hide()
    },
    success: function(data) {

        alertify.set('notifier','position','top-center');
        alertify.success('Updated SuccessFully');
        location.reload(true);


    }
    });

});

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project2023\htdocs\chittagongFront\resources\views/admin/productList/index.blade.php ENDPATH**/ ?>