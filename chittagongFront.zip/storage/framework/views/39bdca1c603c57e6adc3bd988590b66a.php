<?php $__env->startSection('title'); ?>
Role List
<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>



 <!-- Content Header (Page header) -->
 <div class="content-header">
    <div class="d-flex align-items-center">
        <div class="me-auto">
            <h4 class="page-title">Role Information</h4>
        </div>

    </div>
    <div class="row">


        <div class="col-lg-12 col-md-12 col-sm-12">
            <div style="text-align: right;">
                <a href="<?php echo e(route('role.create')); ?>" type="button" class="btn btn-primary btn-sm"><span class="btn-icon-end"><i class="fa fa-plus"></i></span> Add New Role</a>
            </div>
        </div>

    </div>
</div>

<section class="content">
    <div class="row">
        <div class="col-12">
            <div class="box">
                <div class="box-body">

                    <div class="table-responsive">
                        <table id="example" class="table table-bordered table-hover display nowrap margin-top-10 w-p100">
                            <thead>
                                <tr>

                                        <th>Sl</th>
                                        <th>Role Name</th>
                                        <th >Permission List</th>
                                        <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                   <td>

                                    <?php echo e($loop->index+1); ?>


                                    <td><?php echo e($role->name); ?></td>
                                    <td >



                                        <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                        <?php if(($key+1) == 6): ?>
                                            <?php echo e($perm->name); ?>,<br>

                                            <?php elseif(($key+1) == 12): ?>
                                            <?php echo e($perm->name); ?>,<br>
                                            <?php elseif(($key+1) == 18): ?>
                                            <?php echo e($perm->name); ?>,<br>
                                            <?php elseif(($key+1) == 24): ?>

                                            <?php echo e($perm->name); ?>,<br>
                                            <?php elseif(($key+1) == 30): ?>
                                            <?php echo e($perm->name); ?>,<br>

                                            <?php elseif(($key+1) == 36): ?>
                                            <?php echo e($perm->name); ?>,<br>

                                            <?php elseif(($key+1) == 42): ?>
                                            <?php echo e($perm->name); ?>,<br>

                                            <?php elseif(($key+1) == 48): ?>
                                            <?php echo e($perm->name); ?>,<br>

                                            <?php elseif(($key+1) == 54): ?>
                                            <?php echo e($perm->name); ?>,<br>

                                            <?php elseif(($key+1) == 60): ?>
                                            <?php echo e($perm->name); ?>,<br>

                                            <?php else: ?>
                                            <?php echo e($perm->name); ?>,
                                            <?php endif; ?>


                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </td>

                                                <td>


                                                    <button type="button"  onclick="location.href = '<?php echo e(route('role.edit',$role->id)); ?>';"
                                                        class="btn btn-primary shadow btn-xs sharp me-1" >
                                                        <i class="fa fa-edit"></i></button>





                                                        <button type="button" class="btn btn-danger shadow btn-xs sharp" onclick="deleteTag(<?php echo e($role->id); ?>)"><i class="fa fa-trash"></i></button>

 <form id="delete-form-<?php echo e($role->id); ?>" action="<?php echo e(route('role.destroy',$role->id)); ?>" method="POST" style="display: none;">
  <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>

                                                </form>


                                                </td>
                                            </tr>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>
                        </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project2023\htdocs\chittagongFront\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>