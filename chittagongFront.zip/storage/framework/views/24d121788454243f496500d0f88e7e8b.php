<?php $__env->startSection('title'); ?>
<?php echo e($productList->product_name); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('body'); ?>
 <!-- Content Header (Page header) -->
 <div class="content-header">
    <div class="d-flex align-items-center">
        <div class="me-auto">
            <h4 class="page-title">Product Information</h4>
        </div>

    </div>
</div>

<section class="content">
    <div class="box">
        <div class="box-body">
            <div class="row">
                <div class="col-lg-4 col-sm-12">
                    <div class="box box-body b-1 text-center no-shadow">
                        <img src="<?php echo e(asset('/')); ?><?php echo e($productList->product_image); ?>" class="img-fluid" alt=""/>
                    </div>
                </div>
                <div class="col-md-8 col-sm-12">
                    <h2 class="box-title mt-0"><?php echo e($productList->product_name); ?></h2>
                    <div class="list-inline">
                        <a class="text-warning"><i class="mdi mdi-star"></i></a>
                        <a class="text-warning"><i class="mdi mdi-star"></i></a>
                        <a class="text-warning"><i class="mdi mdi-star"></i></a>
                        <a class="text-warning"><i class="mdi mdi-star"></i></a>
                        <a class="text-warning"><i class="mdi mdi-star"></i></a>
                    </div>
                    <h1 class="pro-price mb-0 mt-20"><?php echo e($productList->default_price); ?> Taka
                    </h1>
                    <hr>
                    <p><?php echo e($productList->product_short_description); ?></p>
                    <h4 class="box-title mt-20">Key Highlights</h4>
                    <ul class="list-icons list-unstyled">
                        <li><i class="fa fa-check text-danger me-3"></i> Available Time: <span class="text-success"> <?php echo e($productList->available_time); ?> - <?php echo e($productList->available_till); ?></span></li>
                        <li><i class="fa fa-check text-danger me-3"></i> Approximate TIme: <span class="text-success"> <?php echo e($productList->approximate_time); ?></span></li>
                        <li><i class="fa fa-check text-danger me-3"></i> Visible: <span class="text-success"> <?php echo e($productList->available_status); ?></span></li>
                        <li><i class="fa fa-check text-danger me-3"></i> Category: <span class="text-success"> <?php echo e(\App\Models\Category::where('id',$productList->category_id)->value('category_name')); ?></span></li>
                        <li><i class="fa fa-check text-danger me-3"></i> Sub-Category: <span class="text-success"><?php echo e(\App\Models\SubCategory::where('id',$productList->sub_category_id)->value('subcategory_name')); ?></span></li>
                        <li><i class="fa fa-check text-danger me-3"></i> Product Type: <span class="text-success"> <?php echo e($productList->product_type); ?></span></li>
                    </ul>
                </div>
                <div class="col-md-12 col-sm-12">
                    <table class="table table-bordered">
                        <tr>
                            <td>Item Type</td>
                            <td><?php echo e($productList->item_type); ?></td>
                        </tr>
                        <tr>
                            <td>Discount</td>
                            <td>
                                <span><?php echo e($productList->discount_type); ?></span> <br>
                                <span><?php echo e($productList->discount_price); ?></span>
                            </td>
                        </tr>
                        <tr>
                            <td>Tax</td>
                            <td>
                                <span><?php echo e($productList->tax_type); ?></span> <br>
                                <span><?php echo e($productList->tax_rate); ?></span>
                            </td>
                        </tr>
                        <tr>
                            <td>Addons</td>
                            <td>






                                <ul>
                                    <?php $__currentLoopData = json_decode($productList['product_add_on'],true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addOnId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e(\App\Models\ProductAddOn::where('id',$addOnId)->value('name')); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </td>
                        </tr>
                        <tr>
                            <td>Product Stock</td>
                            <td><?php echo e($productList->product_stock_quantity); ?></td>
                        </tr>
                    </table>






                    <h4>Product Variations</h4>
                    <table class="table table-bordered">
                        <tr>
                            <th>Name</th>
                            <th>Type</th>
                            <th>Min</th>
                            <th>Max</th>
                            <th>Required</th>
                            <th>Other</th>
                        </tr>
                        <?php if(isset($productList->variations)): ?>
                        <?php $__currentLoopData = json_decode($productList->variations,true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key_choice_options=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(isset($item["price"])): ?>
                                <?php break; ?>
                            <?php else: ?>
                        <tr>
                            <td><?php echo e($item['name']); ?></td>
                            <td><?php echo e($item['type']); ?></td>
                            <td><?php echo e($item['min']); ?></td>
                            <td><?php echo e($item['max']); ?></td>
                            <td><?php echo e($item['required']); ?></td>
                            <td>
                                <table class="table table-bordered">
                                    <tr>
                                        <th>Option Name</th>
                                        <th>Additional Price</th>
                                    </tr>
                                    <?php if(isset($item['values'])): ?>
                                    <?php $__currentLoopData = $item['values']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key_value => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($value['label']); ?></td>
                                        <td><?php echo e($value['optionPrice']); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </table>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project2023\htdocs\chittagongFront\resources\views/admin/productList/show.blade.php ENDPATH**/ ?>