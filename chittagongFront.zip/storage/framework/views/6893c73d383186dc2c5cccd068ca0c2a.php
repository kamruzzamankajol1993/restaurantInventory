<?php $__env->startSection('title'); ?>
Designation List | <?php echo e($ins_name); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>


<div class="content-header">
    <div class="d-flex align-items-center">
        <div class="me-auto">
            <h4 class="page-title">Designation Information </h4>
        </div>

    </div>
    <div class="row">


        <div class="col-lg-12 col-md-12 col-sm-12">
            <?php if(Auth::guard('admin')->user()->can('designationAdd')): ?>
            <div style="text-align: right;">
                <button type="button" data-bs-toggle="modal" data-bs-target=".bd-example-modal-lg"class="btn btn-primary btn-sm">Add New Designation<span class="btn-icon-end"><i class="fa fa-plus"></i></span></button>
            </div>
            <?php endif; ?>
        </div>

    </div>
</div>

<section class="content">
    <div class="row">
        <div class="col-12">
            <div class="box">
                <div class="box-body">

                    <?php echo $__env->make('flash_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="table-responsive">
                        <table id="example" class="table table-bordered table-hover display nowrap margin-top-10 w-p100">
                            <thead>
                                <tr>
                                    <th>Sl</th>
                                    <th>Designation Name</th>

                                    <th>Designation Detail</th>
                                    <th>Designation Status</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $designationLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$AllDesignationLists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>

                                    <td><?php echo e($AllDesignationLists->designation_name); ?></td>

                                    <td><?php echo e($AllDesignationLists->designation_detail); ?></td>

                                    <td><?php echo e($AllDesignationLists->status); ?></td>
                                    <td>
                                        <?php if(Auth::guard('admin')->user()->can('designationUpdate')): ?>
                                        <button type="button" data-bs-toggle="modal" data-bs-target=".bs-example-modal-lg<?php echo e($AllDesignationLists->id); ?>"
                                        class="btn btn-primary shadow btn-xs sharp" >
                                        <i class="fa fa-pencil"></i></button>

                                          <!--  Large modal example -->
                                          <div class="modal fade bs-example-modal-lg<?php echo e($AllDesignationLists->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                              <div class="modal-dialog modal-lg">
                                                  <div class="modal-content">
                                                      <div class="modal-header">
                                                          <h5 class="modal-title" id="myLargeModalLabel">Update Information</h5>
                                                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                                                          </button>
                                                      </div>
                                                      <div class="modal-body">
                                                          <form  action="<?php echo e(route('designationList.update',$AllDesignationLists->id )); ?>" method="post" enctype="multipart/form-data" id="form" data-parsley-validate="">
                                                              <?php echo method_field('PUT'); ?>
                                                              <?php echo csrf_field(); ?>



                                                              <div class="mb-3">
                                                                <label class="form-label" for="">Designation Name<span style="color:red;">*</span></label>
                                                                <input class="form-control" name="designation_name" value="<?php echo e($AllDesignationLists->designation_name); ?>"  type="text" placeholder="" required>
                                                            </div>



                                                            <div class="mb-3">
                                                                <label class="form-label" for="">Designation Detail <span style="color:red;">*</span></label>
                                                                <input class="form-control" name="designation_detail" value="<?php echo e($AllDesignationLists->designation_detail); ?>"  type="text"  placeholder="" required>

                                                            </div>



                                                            <div class="mb-3 col-md-12">
                                                                <label class="form-label">Status</label>
                                                                <select id="inputState" name="status" class="form-control ms-0 wide">
                                                                    <option>Choose...</option>
                                                                    <option value="Active" <?php echo e('Active' == $AllDesignationLists->status ? 'selected':''); ?>>Active</option>
                                                                    <option value="Inactive" <?php echo e('Inactive' == $AllDesignationLists->status ? 'selected':''); ?>>Inactive</option>
                                                                </select>
                                                            </div>








                                                              <button type="submit" id="finalButton<?php echo e($AllDesignationLists->id); ?>" class="btn btn-primary mt-4 pr-4 pl-4">Update </button>
                                                          </form>
                                                      </div>
                                                  </div><!-- /.modal-content -->
                                              </div><!-- /.modal-dialog -->
                                          </div><!-- /.modal -->


    <?php endif; ?>

    
    <?php if($AllDesignationLists->id <= 4): ?>

    <?php else: ?>
                                <?php if(Auth::guard('admin')->user()->can('designationDelete')): ?>

    <button   type="button" class="btn btn-danger shadow btn-xs sharp" onclick="deleteTag(<?php echo e($AllDesignationLists->id); ?>)" data-toggle="tooltip" title="Delete"><i class="fa fa-trash"></i></button>
                  <form id="delete-form-<?php echo e($AllDesignationLists->id); ?>" action="<?php echo e(route('designationList.destroy',$AllDesignationLists->id)); ?>" method="POST" style="display: none;">
                    <?php echo method_field('DELETE'); ?>
                                                  <?php echo csrf_field(); ?>

                                              </form>

                                              <?php endif; ?>
                                              <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                </div>
            </div>
        </div>
    </div>
</section>


<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myLargeModalLabel">Add New Designation</h4>
                <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form class="custom-validation"  action="<?php echo e(route('designationList.store')); ?>" method="post" enctype="multipart/form-data" id="form" data-parsley-validate="">
                    <?php echo csrf_field(); ?>


                    <div class="mb-3">
                        <label class="form-label" for="">Designation Name<span style="color:red;">*</span></label>
                        <input class="form-control" required name="designation_name" id="designation_name0" type="text" placeholder="" required>
                    </div>


                    <div class="mb-3">
                        <label class="form-label" for="">Designation Detail <span style="color:red;">*</span></label>

                        <div class="row">


                            <div class="col-md-12">
                                <input class="form-control" name="designation_detail"  id="designation_detail0" type="text"  placeholder="" required>
                            </div>
                        </div>


                    </div>



                    <div class="mb-3 col-md-12">
                        <label class="form-label">Status</label>
                        <select required id="inputState" name="status" class="default-select form-control ms-0 wide">
                            <option value="">Choose...</option>
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                    </div>

                <div class="card-footer text-end ">
                    <button class="btn btn-primary mt-3" id="finalButton0" type="submit">Submit</button>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- branch-->


<script>
    $("[id^=branch_id]").change(function(){
        var main_id = $(this).attr('id');
        var id_for_pass = main_id.slice(9);


        //part one id

        var firstValue = $('#hidden_value'+id_for_pass).val();
        var secondValue = $('#designation_detail'+id_for_pass).val();

        //end part one if


        var branchId = $('#branch_id'+id_for_pass).val();
        var designationName = $('#designation_name'+id_for_pass).val();

        var designationSerial =firstValue + '.'+secondValue;
        //alert(branchId);


        $.ajax({
        url: "<?php echo e(route('showBranchStep')); ?>",
        method: 'GET',
        data: {branchId:branchId},
        success: function(data) {



            $("#serial_part_one"+id_for_pass).val(data);
            $("#hidden_value"+id_for_pass).val(data);




        }
        });

        //

        $.ajax({
        url: "<?php echo e(route('checkDesignation')); ?>",
        method: 'GET',
        data: {branchId:branchId,designationName:designationName,designationSerial:designationSerial},
        success: function(data) {

            if(data >= 1){

                $("#result"+id_for_pass).html('You Have Already Add This Step');
                $("#finalButton"+id_for_pass).hide();

            }else{

                $("#result"+id_for_pass).html('');
                $("#finalButton"+id_for_pass).show();
            }


        }
        });



        //alert(id_for_pass);
    });
    </script>
<!-- end branch -->

<!-- designation -->
<script>
    $("[id^=designation_name]").keyup(function(){
        var main_id = $(this).attr('id');
        var id_for_pass = main_id.slice(16);


        var branchId = $('#branch_id'+id_for_pass).val();
        var designationName = $('#designation_name'+id_for_pass).val();

        var designationSerial = $('#designation_detail'+id_for_pass).val();
        //alert(branchId);


        $.ajax({
        url: "<?php echo e(route('checkDesignation')); ?>",
        method: 'GET',
        data: {branchId:branchId,designationName:designationName,designationSerial:designationSerial},
        success: function(data) {

            if(data >= 1){

                $("#result"+id_for_pass).html('You Have Already Add This Step');
                $("#finalButton"+id_for_pass).hide();

            }else{

                $("#result"+id_for_pass).html('');
                $("#finalButton"+id_for_pass).show();
            }


        }
        });



        //alert(id_for_pass);
    });
    </script>
<!-- end designation -->


<!--step-->
<script>
    $("[id^=designation_detail]").keyup(function(){
        var main_id = $(this).attr('id');
        var id_for_pass = main_id.slice(18);


        //part one id

        var firstValue = $('#hidden_value'+id_for_pass).val();
        var secondValue = $('#designation_detail'+id_for_pass).val();

        //end part one if


        var branchId = $('#branch_id'+id_for_pass).val();
        var designationName = $('#designation_name'+id_for_pass).val();

        var designationSerial =firstValue + '.'+secondValue;
        //alert(branchId);


        $.ajax({
        url: "<?php echo e(route('checkDesignation')); ?>",
        method: 'GET',
        data: {branchId:branchId,designationName:designationName,designationSerial:designationSerial},
        success: function(data) {

            if(data >= 1){

                $("#result"+id_for_pass).html('You Have Already Add This Step');
                $("#finalButton"+id_for_pass).hide();

            }else{

                $("#result"+id_for_pass).html('');
                $("#finalButton"+id_for_pass).show();
            }


        }
        });



        //alert(id_for_pass);
    });
    </script>
    <!--end step-->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project2023\htdocs\chittagongFront\resources\views/admin/designationList/index.blade.php ENDPATH**/ ?>