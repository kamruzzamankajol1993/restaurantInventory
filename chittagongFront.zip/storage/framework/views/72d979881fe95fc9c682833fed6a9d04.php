<?php
$usr = Auth::guard('admin')->user();
?>

<aside class="main-sidebar">
    <!-- sidebar-->
    <section class="sidebar position-relative">
        <div class="multinav">
            <div class="multinav-scroll" style="height: 100%;">
                <!-- sidebar menu-->
                <ul class="sidebar-menu" data-widget="tree">

                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="icon-Home"><span class="path1"></span><span class="path2"></span></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="treeview">
                        <a href="#">
                            <i class="icon-Cart"><span class="path1"></span><span class="path2"></span><span class="path3"></span></i>
                            <span>POS</span>
                            <span class="pull-right-container">
					  <i class="fa fa-angle-right pull-right"></i>
					</span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if($usr->can('posAdd')): ?>
                            <li class="<?php echo e(Route::is('pos.create')  ? 'active' : ''); ?>"><a href="<?php echo e(route('pos.create')); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>New Order</a></li>
                            <?php endif; ?>
                            <?php if($usr->can('posView') || $usr->can('posDelete') || $usr->can('posUpdate')): ?>
                            <li class="<?php echo e(Route::is('pos.index') || Route::is('pos.show') || Route::is('pos.edit')   ? 'active' : ''); ?>"><a href="<?php echo e(route('pos.index')); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Order List</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>

                    <li class="header">Order Management</li>

                    <li class="treeview">
                        <a href="#">
                            <i class="icon-Clipboard-check"><span class="path1"></span><span class="path2"></span><span class="path3"></span></i>
                            <span>Orders</span>
                            <span class="pull-right-container">
					  <i class="fa fa-angle-right pull-right"></i>
					</span>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="#"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>All</a></li>
                            <li><a href="#"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Pending</a></li>
                            <li><a href="#"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Confirmed</a></li>
                            <li><a href="#"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Processing</a></li>
                            <li><a href="#"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Out of Delivery</a></li>
                            <li><a href="#"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Delivered</a></li>
                            <li><a href="#"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Return</a></li>
                            <li><a href="#"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Failed To Deliver</a></li>
                            <li><a href="#"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Cancel</a></li>
                            <li><a href="#"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Scheduled</a></li>
                        </ul>
                    </li>
                    <li class="treeview">
                        <a href="#">
                            <i class="icon-Cardboard-vr"><span class="path1"></span><span class="path2"></span><span class="path3"></span></i>
                            <span>Table Orders</span>
                            <span class="pull-right-container">
					  <i class="fa fa-angle-right pull-right"></i>
					</span>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="#"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>All</a></li>
                            <li><a href="#"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Confirmed</a></li>
                            <li><a href="#"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Cooking</a></li>
                            <li><a href="#"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Ready For Server</a></li>
                            <li><a href="#"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Complete</a></li>
                            <li><a href="#"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Cancel</a></li>
                            <li><a href="#"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>On Table</a></li>
                        </ul>
                    </li>

                    <li class="header">Product Management</li>

                    <li class="treeview">
                        <a href="#">
                            <i class="icon-Chart-bar"><span class="path1"></span><span class="path2"></span><span class="path3"></span></i>
                            <span>Category Setup</span>
                            <span class="pull-right-container">
					  <i class="fa fa-angle-right pull-right"></i>
					</span>
                        </a>
                        <ul class="treeview-menu">

                            <?php if($usr->can('categoryAdd') || $usr->can('categoryView') ||  $usr->can('categoryDelete') ||  $usr->can('categoryUpdate')): ?>
                            <li class="<?php echo e(Route::is('categoryList.index') || Route::is('categoryList.edit') || Route::is('categoryList.create') ? 'active' : ''); ?>"><a href="<?php echo e(route('categoryList.index')); ?>" class="<?php echo e(Route::is('categoryList.index') || Route::is('categoryList.edit') || Route::is('categoryList.create') ? 'active' : ''); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Category List</a></li>
                            <?php endif; ?>
                            <?php if($usr->can('subcategoryAdd') || $usr->can('subcategoryView') ||  $usr->can('subcategoryDelete') ||  $usr->can('subcategoryUpdate')): ?>
                            <li class="<?php echo e(Route::is('subcategoryList.index') || Route::is('subcategoryList.edit') || Route::is('subcategoryList.create') ? 'active' : ''); ?>"><a href="<?php echo e(route('subcategoryList.index')); ?>" class="<?php echo e(Route::is('subcategoryList.index') || Route::is('subcategoryList.edit') || Route::is('subcategoryList.create') ? 'active' : ''); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Sub Category List</a></li>
                            <?php endif; ?>



                        </ul>
                    </li>
                    <li class="treeview">
                        <a href="#">
                            <i class="icon-Menu"><span class="path1"></span><span class="path2"></span><span class="path3"></span></i>
                            <span>Product Setup</span>
                            <span class="pull-right-container">
					  <i class="fa fa-angle-right pull-right"></i>
					</span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if($usr->can('productAttributeAdd') || $usr->can('productAttributeView') ||  $usr->can('productAttributeDelete') ||  $usr->can('productAttributeUpdate')): ?>
                            <li class="<?php echo e(Route::is('productAttribute.index') || Route::is('productAttributeSearch.index') ? 'active' : ''); ?>"><a href="<?php echo e(route('productAttribute.index')); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Product Attributes</a></li>
                            <?php endif; ?>
                            <?php if($usr->can('productAddOnAdd') || $usr->can('productAddOnView') ||  $usr->can('productAddOnDelete') ||  $usr->can('productAddOnUpdate')): ?>
                            <li class="<?php echo e(Route::is('productAddOn.index') || Route::is('productAddOnSearch.index') ? 'active' : ''); ?>"><a href="<?php echo e(route('productAddOn.index')); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Product Addon</a></li>
                            <?php endif; ?>
                            <?php if($usr->can('productAdd')): ?>
                            <li class="<?php echo e(Route::is('productList.create')  ? 'active' : ''); ?>"><a href="<?php echo e(route('productList.create')); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Product Add</a></li>
                            <?php endif; ?>
                            <?php if($usr->can('productAdd') || $usr->can('productView') ||  $usr->can('productDelete') ||  $usr->can('productUpdate')): ?>
                            <li class="<?php echo e(Route::is('productList.index') || Route::is('productList.edit') || Route::is('productList.view') ? 'active' : ''); ?>"><a href="<?php echo e(route('productList.index')); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Product List</a></li>
                            <?php endif; ?>
                            <li><a href="#"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Bulk Import</a></li>
                            <li><a href="#"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Bulk Export</a></li>
                            <li><a href="#"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Product Reviews</a></li>

                        </ul>
                    </li>


                    <li class="header">Qr Code  Management</li>


                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-qrcode"><span class="path1"></span><span class="path2"></span></i>
                            <span>Qr Code & Table</span>
                            <span class="pull-right-container">
					  <i class="fa fa-angle-right pull-right"></i>
					</span>
                        </a>
                        <ul class="treeview-menu">


                    <?php if($usr->can('tableAdd') || $usr->can('tableView') ||  $usr->can('tableDelete') ||  $usr->can('tableUpdate')): ?>
                    <li class="<?php echo e(Route::is('tableList.index') || Route::is('tableList.edit') || Route::is('tableList.create') ? 'active' : ''); ?>"><a href="<?php echo e(route('tableList.index')); ?>" class="<?php echo e(Route::is('tableList.index') || Route::is('tableList.edit') || Route::is('tableList.create') ? 'active' : ''); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Table List</a></li>
                    <?php endif; ?>
                    <?php if($usr->can('qrAdd') || $usr->can('qrView') ||  $usr->can('qrDelete') ||  $usr->can('qrUpdate')): ?>
                    <li class="<?php echo e(Route::is('qrCodeList.index') || Route::is('qrCodeList.edit') || Route::is('qrCodeList.create') ? 'active' : ''); ?>"><a href="<?php echo e(route('qrCodeList.index')); ?>" class="<?php echo e(Route::is('qrCodeList.index') || Route::is('qrCodeList.edit') || Route::is('qrCodeList.create') ? 'active' : ''); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>QR CODE List</a></li>
                    <?php endif; ?>

                        </ul>
                    </li>

                    <li class="header">User Management</li>

                    <?php if($usr->can('designationAdd') || $usr->can('designationView') ||  $usr->can('designationDelete') ||  $usr->can('designationUpdate')): ?>
                    <li class="<?php echo e(Route::is('designationList.index') || Route::is('designationList.edit') || Route::is('designationList.create') ? 'active' : ''); ?>"><a href="<?php echo e(route('designationList.index')); ?>" class="<?php echo e(Route::is('designationList.index') || Route::is('designationList.edit') || Route::is('designationList.create') ? 'active' : ''); ?>"><i class="fa fa-file"><span class="path1"></span><span class="path2"></span></i>Designation List</a></li>
                    <?php endif; ?>

                    <li class="treeview">
                        <a href="#">
                            <i class="icon-Group"><span class="path1"></span><span class="path2"></span></i>
                            <span>Customer</span>
                            <span class="pull-right-container">
					  <i class="fa fa-angle-right pull-right"></i>
					</span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if($usr->can('customerAdd')): ?>
                    <li class="<?php echo e(Route::is('customer.create') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('customer.create')); ?>" class="<?php echo e(Route::is('customer.create') ? 'active' : ''); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Customer Add</a>
                    </li>
                    <?php endif; ?>

                    <?php if($usr->can('customerView') || $usr->can('customerDelete') || $usr->can('customerUpdate')): ?>
                    <li class="<?php echo e(Route::is('customer.index') || Route::is('customer.edit') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('customer.index')); ?>" class="<?php echo e(Route::is('customer.index') || Route::is('customer.edit') ? 'active' : ''); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Customer List</a>
                    </li>
                    <?php endif; ?>
                        </ul>
                    </li>
                    <li class="treeview">
                        <a href="#">
                            <i class="icon-Tie"><span class="path1"></span><span class="path2"></span></i>
                            <span>Employees</span>
                            <span class="pull-right-container">
					  <i class="fa fa-angle-right pull-right"></i>
					</span>
                        </a>
                        <ul class="treeview-menu">

                            <?php if($usr->can('userAdd')): ?>
                    <li class="<?php echo e(Route::is('user.create') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('user.create')); ?>" class="<?php echo e(Route::is('user.create') ? 'active' : ''); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Employees Add</a>
                    </li>
                    <?php endif; ?>

                    <?php if($usr->can('userView') || $usr->can('userDelete') || $usr->can('userUpdate')): ?>
                    <li class="<?php echo e(Route::is('user.index') || Route::is('user.edit') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('user.index')); ?>" class="<?php echo e(Route::is('user.index') || Route::is('user.edit') ? 'active' : ''); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Employees List</a>
                    </li>
                    <?php endif; ?>


                        </ul>
                    </li>




                    <li class="header">System Management</li>

                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-gear"><span class="path1"></span><span class="path2"></span></i>
                            <span>General Setting</span>
                            <span class="pull-right-container">
					  <i class="fa fa-angle-right pull-right"></i>
					</span>
                        </a>
                        <ul class="treeview-menu">




                            <?php if($usr->can('systemInformationAdd') || $usr->can('systemInformationView') || $usr->can('systemInformationDelete') || $usr->can('systemInformationUpdate')): ?>
                            <li class="<?php echo e(Route::is('systemInformation.index') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('systemInformation.index')); ?>" class="<?php echo e(Route::is('systemInformation.index') ? 'active' : ''); ?>" ><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>System</a>
                            </li>
                            <?php endif; ?>

                            <?php if($usr->can('roleAdd') || $usr->can('roleView') || $usr->can('roleDelete') || $usr->can('roleUpdate')): ?>
                            <li class="<?php echo e(Route::is('role.index') || Route::is('role.edit') || Route::is('role.create') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('role.index')); ?>" class="<?php echo e(Route::is('role.index') || Route::is('role.edit') || Route::is('role.create') ? 'active' : ''); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Role</a>
                            </li>
                            <?php endif; ?>
                            <?php if($usr->can('permissionAdd') || $usr->can('permissionView') || $usr->can('permissionDelete') || $usr->can('permissionUpdate')): ?>
                            <li class="<?php echo e(Route::is('permission.index') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('permission.index')); ?>" class="<?php echo e(Route::is('permission.index') ? 'active' : ''); ?>"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i><span>Permission</span>
                            </a>
                            </li>
                            <?php endif; ?>


                        </ul>
                    </li>

                </ul>

                <div class="sidebar-widgets">
                    <div class="mx-25 mb-30 pb-20 side-bx bg-primary bg-food-dark rounded20">
                        <div class="text-center">
                            <img src="<?php echo e(asset('/')); ?>public/admin/assets/images/res-menu.png" class="sideimg" alt="">
                            <h3 class="title-bx">Add Menu</h3>
                            <?php if($usr->can('menuListAdd') || $usr->can('menuListView') ||  $usr->can('menuListDelete') ||  $usr->can('menuListUpdate')): ?>
                            <a href="<?php echo e(route('menuList.index')); ?>" class="text-white py-10 fs-16 mb-0">
                                Manage Your food and beverages menu</i>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="copyright text-start m-25">
                        <p><strong class="d-block"><?php echo e($ins_name); ?></strong> © 2024 All Rights Reserved</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</aside>

<?php /**PATH F:\project2023\htdocs\chittagongFront\resources\views/admin/include/headerLeft.blade.php ENDPATH**/ ?>