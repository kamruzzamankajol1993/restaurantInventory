<?php
return [
    'hour' => 6,
    'language' => 'bn',
    'format' => 'd m y'
];
