<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content=""/>
    <meta name="author" content=""/>
    <meta name="robots" content=""/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="FoodieScan - Food Restaurant Management Software"/>
    <meta property="og:title" content="FoodieScan - Food Restaurant Management Software"/>
    <meta property="og:description" content="FoodieScan - Food Restaurant Management Software"/>
    <meta property="og:image" content="social-image.png"/>
    <meta name="format-detection" content="telephone=no">

    <!-- PAGE TITLE HERE -->
    <title>FoodieScan</title>

    <!-- FAVICONS ICON -->
    <link rel="shortcut icon" type="image/png" href="assets/images/favicon.png"/>
    <link href="assets/vendor/jquery-nice-select/css/nice-select.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css" rel="stylesheet">

    <!-- Style css -->
    <link href="assets/vendor/swiper/css/swiper-bundle.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
    <link href="assets/vendor/swiper/css/swiper-bundle.min.css" rel="stylesheet">

    <!-- Custom css-->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/mtech.css" rel="stylesheet">


</head>

<body>

<!--*******************
    Preloader start
********************-->
<?php include 'preloader.php'; ?>
<!--*******************
    Preloader end
********************-->

<!--**********************************
    Main wrapper start
***********************************-->

<div id="main-wrapper">

    <!--**********************************
        Nav header start
    ***********************************-->
    <?php include 'top_header.php'; ?>
    <!--**********************************
        Nav header end
    ***********************************-->

    <!--**********************************
    Header start
    ***********************************-->
    <?php include 'top_header_right.php'; ?>
    <!--**********************************
        Header end ti-comment-alt
    ***********************************-->

    <!--**********************************
    Sidebar start
    ***********************************-->
    <?php include 'left_header.php'; ?>
    <!--**********************************
        Sidebar end
    ***********************************-->

    <!--**********************************
        Content body start
    ***********************************-->
    <div class="content-body">
        <div class="container">
            <div class="row page-titles">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active">Food Order Process</li>
                </ol>
            </div>
            <!-- row -->


            <div class="row">
                <div class="col-xl-12 col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="basic-form">
                                <form>
                                    <div class="row">
                                        <div class="mb-3 col-md-6">
                                            <label class="form-label">Invoice Number</label>
                                            <input type="number" class="form-control">
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label class="form-label">Customer</label>
                                            <select id="inputState" class="default-select form-control ms-0 wide">
                                                <option selected>Choose...</option>
                                                <option>Walk in</option>
                                                <option>Dear X</option>
                                                <option>Dear Y</option>
                                            </select>
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label class="form-label">Customer Type</label>
                                            <select id="inputState" class="default-select form-control ms-0 wide">
                                                <option selected>Choose...</option>
                                                <option>Dine In Customer</option>
                                                <option>Online Customer</option>
                                                <option>Third Party Food Delivery</option>
                                                <option>QR Customer</option>
                                            </select>
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label class="form-label">Select Table</label>
                                            <select id="inputState" class="default-select form-control ms-0 wide">
                                                <option selected>Choose...</option>
                                                <option>Table 01</option>
                                                <option>Table 02</option>
                                            </select>
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label class="form-label">Select Waiter</label>
                                            <select id="inputState" class="default-select form-control ms-0 wide">
                                                <option selected>Choose...</option>
                                                <option>Waiter 01</option>
                                                <option>Waiter 02</option>
                                            </select>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-12 col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="basic-form">
                                <form>
                                    <table class="table table-borderless" id="dynamicAddRemove">
                                        <tr>
                                            <th>Food Item</th>
                                            <th>Amount</th>
                                            <th>Quantity</th>
                                            <th>Total Amount</th>
                                            <th>End Time</th>
                                        </tr>
                                        <tr>
                                            <td>
                                                <select  class="default-select form-control ms-0 wide">
                                                    <option selected>Choose...</option>
                                                    <option>Walk in</option>
                                                    <option>Dear X</option>
                                                    <option>Dear Y</option>
                                                </select>
                                            </td>
                                            <td>
                                                <input type="number" name="" value=""
                                                       class="form-control"/>
                                            </td>
                                            <td>
                                                <input type="number" name="" value=""
                                                       class="form-control"/>
                                            </td>
                                            <td>
                                                <input type="number" name="" value=""
                                                       class="form-control"/>
                                            </td>
                                            <td>
                                                <button type="button" name="add" id="dynamic-ar"
                                                        class="btn btn-outline-primary"><i class="fa fa-plus"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    </table>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-8 cik-lg-8 col-md-12 col-sm-12"></div>
                <div class="col-lg-4 col-md-4 col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-borderless"
                                       style="background-color:#F5F5F5;">

                                    <tbody>
                                    <tr>
                                        <td>Total Tax</td>
                                        <td>
                                            <input type="number" class="form-control">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Total Discount</td>
                                        <td>
                                            <input type="number" class="form-control">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Grand Total</td>
                                        <td>
                                            <input type="number" class="form-control">
                                        </td>
                                    </tr>
                                </table>
                            </div>
                            <button type="submit" class="btn btn-primary" onclick="location.href='invoice.php'">Submit</button>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!--**********************************
        Content body end
    ***********************************-->

    <!--**********************************
    Footer start
    ***********************************-->
    <?php include 'footer.php'; ?>
    <!--**********************************
        Footer end
    ***********************************-->
</div>


<!--**********************************
    Scripts
***********************************-->

<!-- Required vendors -->
<script src="assets/vendor/global/global.min.js"></script>
<script src="assets/vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<script src="assets/vendor/chart.js/Chart.bundle.min.js"></script>
<script src="assets/vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>

<!-- Apex Chart -->
<script src="assets/vendor/apexchart/apexchart.js"></script>

<script src="assets/vendor/bootstrap-datetimepicker/js/moment.js"></script>
<script src="assets/vendor/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>
<script src="assets/vendor/peity/jquery.peity.min.js"></script>
<script src="assets/vendor/swiper/js/swiper-bundle.min.js"></script>

<!-- Datatable -->
<script src="assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
<script src="assets/js/plugins-init/datatables.init.js"></script>


<!-- Dashboard 1 -->
<script src="assets/js/dashboard/dashboard-2.js"></script>

<script src="assets/js/dlabnav-init.js"></script>
<script src="assets/js/custom.js"></script>

<script type="text/javascript">
    var i = 0;
    $("#dynamic-ar").click(function () {
        ++i;
        $("#dynamicAddRemove").append('<tr>' +
            '<td>' +
            ' <select class="default-select form-control ms-0 wide" aria-label="Default select example">' +
            '<option value="1">One</option><option value="2">Two</option><option value="3">Three</option></select>' +
            '</td>' +
            '<td>' +
            '<input type="text" name="" value="" class="form-control" /></td>' +
            '<td>' +
            '<input type="text" name="" value="" class="form-control" /></td>' +
            '<td>' +
            '<input type="text" name="" value="" class="form-control" /></td>' +
            '<td><button type="button" class="btn btn-outline-danger remove-input-field"><i class="fa fa-trash"></i></button></td></tr>'
        );
    });
    $(document).on('click', '.remove-input-field', function () {
        $(this).parents('tr').remove();
    });
</script>

</body>

</html>