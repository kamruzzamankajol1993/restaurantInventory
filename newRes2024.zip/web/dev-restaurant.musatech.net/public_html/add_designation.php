<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="" />
    <meta name="author" content="" />
    <meta name="robots" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="FoodieScan - Food Restaurant Management Software" />
    <meta property="og:title" content="FoodieScan - Food Restaurant Management Software" />
    <meta property="og:description" content="FoodieScan - Food Restaurant Management Software" />
    <meta property="og:image" content="social-image.png" />
    <meta name="format-detection" content="telephone=no">

    <!-- PAGE TITLE HERE -->
    <title>FoodieScan</title>

    <!-- FAVICONS ICON -->
    <link rel="shortcut icon" type="image/png" href="assets/images/favicon.png" />
    <link href="assets/vendor/jquery-nice-select/css/nice-select.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css" rel="stylesheet">

    <!-- Style css -->
    <link href="assets/vendor/swiper/css/swiper-bundle.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
    <link href="assets/vendor/swiper/css/swiper-bundle.min.css" rel="stylesheet">

    <!-- Datatable -->
    <link href="assets/vendor/datatables/css/jquery.dataTables.min.css" rel="stylesheet">
    <!-- Custom Stylesheet -->
    <link href="assets/vendor/jquery-nice-select/css/nice-select.css" rel="stylesheet">

    <!-- Custom css-->
    <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>

<!--*******************
    Preloader start
********************-->
<?php include 'preloader.php'; ?>
<!--*******************
    Preloader end
********************-->

<!--**********************************
    Main wrapper start
***********************************-->

<div id="main-wrapper">

    <!--**********************************
        Nav header start
    ***********************************-->
    <?php include 'top_header.php'; ?>
    <!--**********************************
        Nav header end
    ***********************************-->

    <!--**********************************
    Header start
    ***********************************-->
    <?php include 'top_header_right.php'; ?>
    <!--**********************************
        Header end ti-comment-alt
    ***********************************-->

    <!--**********************************
    Sidebar start
    ***********************************-->
    <?php include 'left_header.php'; ?>
    <!--**********************************
        Sidebar end
    ***********************************-->

    <!--**********************************
        Content body start
    ***********************************-->
    <div class="content-body">
        <div class="container">

            <div class="row page-titles">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">Designation List</li>
                        </ol>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div style="text-align: right;">
                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target=".bd-example-modal-lg">Add New Designation<span class="btn-icon-end"><i class="fa fa-plus"></i></span></button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- row -->


            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Designation List</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="example3" class="display text-center">
                                    <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>Designation Name</th>
                                        <th>Details</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>01</td>
                                        <td>X</td>
                                        <td>asdsdasd</td>
                                        <td>Active</td>
                                        <td>
                                            <div class="d-flex">
                                                <a href="#" class="btn btn-primary shadow btn-xs sharp me-1"><i class="fas fa-edit"></i></a>
                                                <a href="#" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a>
                                            </div>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--**********************************
        Content body end
    ***********************************-->

    <!--**********************************
    Footer start
    ***********************************-->
    <?php include 'footer.php'; ?>
    <!--**********************************
        Footer end
    ***********************************-->
</div>


<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Designation</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal">
                </button>
            </div>
            <div class="modal-body">
                <form>
                    <div class="row">
                        <div class="mb-3 col-md-12">
                            <label class="form-label">Designation Name</label>
                            <input type="text" class="form-control">
                        </div>
                        <div class="mb-3 col-md-12">
                            <label class="form-label">Designation Details</label>
                            <input type="text" class="form-control">
                        </div>
                        <div class="mb-3 col-md-12">
                            <label class="form-label">Status</label>
                            <select id="inputState" class="default-select form-control ms-0 wide">
                                <option selected>Choose...</option>
                                <option>Active</option>
                                <option>Inactive</option>
                            </select>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger light btn-sm" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>


<!--**********************************
    Scripts
***********************************-->

<!-- Required vendors -->
<script src="assets/vendor/global/global.min.js"></script>
<script src="assets/vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<script src="assets/vendor/chart.js/Chart.bundle.min.js"></script>
<script src="assets/vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>

<!-- Apex Chart -->
<script src="assets/vendor/apexchart/apexchart.js"></script>

<script src="assets/vendor/bootstrap-datetimepicker/js/moment.js"></script>
<script src="assets/vendor/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>
<script src="assets/vendor/peity/jquery.peity.min.js"></script>
<script src="assets/vendor/swiper/js/swiper-bundle.min.js"></script>

<!-- Datatable -->
<script src="assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
<script src="assets/js/plugins-init/datatables.init.js"></script>


<!-- Dashboard 1 -->
<script src="assets/js/dashboard/dashboard-2.js"></script>

<script src="assets/js/dlabnav-init.js"></script>
<script src="assets/js/custom.js"></script>

</body>

</html>