<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="" />
    <meta name="author" content="" />
    <meta name="robots" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="FoodieScan - Food Restaurant Management Software" />
    <meta property="og:title" content="FoodieScan - Food Restaurant Management Software" />
    <meta property="og:description" content="FoodieScan - Food Restaurant Management Software" />
    <meta property="og:image" content="social-image.png" />
    <meta name="format-detection" content="telephone=no">

    <!-- PAGE TITLE HERE -->
    <title>FoodieScan</title>

    <!-- FAVICONS ICON -->
    <link rel="shortcut icon" type="image/png" href="assets/images/favicon.png" />
    <link href="assets/vendor/jquery-nice-select/css/nice-select.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css" rel="stylesheet">

    <!-- Style css -->
    <link href="assets/vendor/swiper/css/swiper-bundle.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
    <link href="assets/vendor/swiper/css/swiper-bundle.min.css" rel="stylesheet">

    <!-- Custom css-->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/mtech.css" rel="stylesheet">


</head>

<body>

<!--*******************
    Preloader start
********************-->
<?php include 'preloader.php'; ?>
<!--*******************
    Preloader end
********************-->

<!--**********************************
    Main wrapper start
***********************************-->

<div id="main-wrapper">

    <!--**********************************
        Nav header start
    ***********************************-->
    <?php include 'top_header.php'; ?>
    <!--**********************************
        Nav header end
    ***********************************-->

    <!--**********************************
    Header start
    ***********************************-->
    <?php include 'top_header_right.php'; ?>
    <!--**********************************
        Header end ti-comment-alt
    ***********************************-->

    <!--**********************************
    Sidebar start
    ***********************************-->
    <?php include 'left_header.php'; ?>
    <!--**********************************
        Sidebar end
    ***********************************-->

    <!--**********************************
        Content body start
    ***********************************-->
    <div class="content-body">
        <div class="container">
            <div class="row page-titles">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active">Kitchen</li>
                    <li class="breadcrumb-item">Order List</li>
                </ol>
            </div>
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Order List & Status</h4>
                        </div>
                        <div class="card-body">
                            <ul class="nav nav-pills mb-4 dark">
                                <li class=" nav-item">
                                    <a href="#navpills-1" class="nav-link active" data-bs-toggle="tab" aria-expanded="false">New Order</a>
                                </li>
                                <li class="nav-item">
                                    <a href="#navpills-2" class="nav-link" data-bs-toggle="tab" aria-expanded="false">Ongoing</a>
                                </li>
                                <li class="nav-item">
                                    <a href="#navpills-3" class="nav-link" data-bs-toggle="tab" aria-expanded="true">Complete</a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div id="navpills-1" class="tab-pane active">
                                    <div class="row">
                                        <div class="col-xl-12 col-xxl-12">
                                            <div class="row">
                                                <div class="col-xl-4 col-sm-6 sp15">
                                                    <div class="card h-auto b-hover">
                                                        <div class="card-body px-3">
                                                            <div class="text-center">
                                                                <h4>Order #1</h4>
                                                                <p>Nov 11, 2022 , 18:38 PM</p>
                                                            </div>
                                                            <hr>
                                                            <div>
                                                                <h4>Fast Food Resto</h4>
                                                                <div class="d-flex align-items-center">
                                                                    <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path d="M8 0.500031L9.79611 6.02789H15.6085L10.9062 9.4443L12.7023 14.9722L8 11.5558L3.29772 14.9722L5.09383 9.4443L0.391548 6.02789H6.20389L8 0.500031Z" fill="#FC8019"/>
                                                                    </svg>
                                                                    <p class="mb-0 px-2">5.0</p>
                                                                    <svg class="me-2" width="4" height="5" viewBox="0 0 4 5" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <circle cx="2" cy="2.50003" r="2" fill="#C4C4C4"/>
                                                                    </svg>
                                                                    <p class="mb-0">1k+ Reviews</p>
                                                                </div>
                                                                <hr>
                                                            </div>
                                                            <div class="d-flex align-items-center justify-content-between mb-2">
                                                                <span>Delivery Time </span>
                                                                <h6 class="mb-0">10 Min</h6>
                                                            </div>
                                                            <div class="d-flex align-items-center justify-content-between">
                                                                <span>Distance</span>
                                                                <h6 class="mb-0">2.5 Km</h6>
                                                            </div>
                                                            <hr>
                                                            <div class="order-menu">
                                                                <h6 class="font-w600">Order Menu</h6>
                                                                <div class="d-flex align-items-center mb-2">
                                                                    <img class="me-2" src="assets/images/popular-img/review-img/pic-1.jpg" alt="">
                                                                    <div class="order-items">
                                                                        <h6 class="font-w500 text-nowrap mb-0"><a href="javascript:void(0);">Pepperoni Pizza</a></h6>
                                                                        <p class="mb-0">x1</p>
                                                                    </div>
                                                                    <h6 class="text-primary mb-0 ms-auto">+$5.59</h6>
                                                                </div>
                                                                <div class="d-flex align-items-center">
                                                                    <img class="me-2" src="assets/images/popular-img/pic-1.jpg" alt="">
                                                                    <div class="order-items">
                                                                        <h6 class="font-w500 text-nowrap mb-0"><a href="javascript:void(0);">Fish Burger</a></h6>
                                                                        <p class="mb-0">x1</p>
                                                                    </div>
                                                                    <h6 class="text-primary mb-0 ms-auto">+$5.59</h6>
                                                                </div>
                                                                <hr>
                                                                <div class="d-flex align-items-center justify-content-between mb-4">
                                                                    <h4 class="mb-0">Total</h4>
                                                                    <h4 class="mb-0 text-primary">$202.00</h4>
                                                                </div>
                                                                <a href="javascript:void(0);" class="btn btn-outline-primary bgl-primary btn-block">Confirm</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-xl-4 col-sm-6 sp15">
                                                    <div class="card h-auto b-hover">
                                                        <div class="card-body px-3">
                                                            <div class="text-center">
                                                                <h4>Order #2</h4>
                                                                <p>Nov 11, 2022 , 18:38 PM</p>
                                                            </div>
                                                            <hr>
                                                            <div>
                                                                <h4>Fast Food Resto</h4>
                                                                <div class="d-flex align-items-center">
                                                                    <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path d="M8 0.500031L9.79611 6.02789H15.6085L10.9062 9.4443L12.7023 14.9722L8 11.5558L3.29772 14.9722L5.09383 9.4443L0.391548 6.02789H6.20389L8 0.500031Z" fill="#FC8019"/>
                                                                    </svg>
                                                                    <p class="mb-0 px-2">5.0</p>
                                                                    <svg class="me-2" width="4" height="5" viewBox="0 0 4 5" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <circle cx="2" cy="2.50003" r="2" fill="#C4C4C4"/>
                                                                    </svg>
                                                                    <p class="mb-0">1k+ Reviews</p>
                                                                </div>
                                                                <hr>
                                                            </div>
                                                            <div class="d-flex align-items-center justify-content-between mb-2">
                                                                <span>Delivery Time </span>
                                                                <h6 class="mb-0">10 Min</h6>
                                                            </div>
                                                            <div class="d-flex align-items-center justify-content-between">
                                                                <span>Distance</span>
                                                                <h6 class="mb-0">2.5 Km</h6>
                                                            </div>
                                                            <hr>
                                                            <div class="order-menu">
                                                                <h6>Order Menu</h6>
                                                                <div class="d-flex align-items-center mb-2">
                                                                    <img class="me-2" src="assets/images/popular-img/review-img/pic-2.jpg" alt="">
                                                                    <div class="order-items">
                                                                        <h6 class="font-w500 text-nowrap mb-0"><a href="javascript:void(0);">Japan Ramen</a></h6>
                                                                        <p class="mb-0">x1</p>
                                                                    </div>
                                                                    <h6 class="text-primary mb-0 ms-auto">+$5.59</h6>
                                                                </div>
                                                                <div class="d-flex align-items-center">
                                                                    <img class="me-2" src="assets/images/popular-img/pic-2.jpg" alt="">
                                                                    <div class="order-items">
                                                                        <h6 class="font-w500 text-nowrap mb-0"><a href="javascript:void(0);">Beef Burger</a></h6>
                                                                        <p class="mb-0">x1</p>
                                                                    </div>
                                                                    <h6 class="text-primary mb-0 ms-auto">+$5.59</h6>
                                                                </div>
                                                                <hr>
                                                                <div class="d-flex align-items-center justify-content-between mb-4">
                                                                    <h4 class="mb-0">Total</h4>
                                                                    <h4 class="mb-0 text-primary">$202.00</h4>
                                                                </div>
                                                                <a href="javascript:void(0);" class="btn btn-outline-primary bgl-primary btn-block">Confirm</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="navpills-2" class="tab-pane">
                                    <div class="row">
                                        <div class="col-xl-12 col-xxl-12">
                                            <div class="row">
                                                <div class="col-xl-4 col-sm-6 sp15">
                                                    <div class="card h-auto b-hover">
                                                        <div class="card-body px-3">
                                                            <div class="text-center">
                                                                <h4>Order #1</h4>
                                                                <p>Nov 11, 2022 , 18:38 PM</p>
                                                            </div>
                                                            <hr>
                                                            <div>
                                                                <h4>Fast Food Resto</h4>
                                                                <div class="d-flex align-items-center">
                                                                    <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path d="M8 0.500031L9.79611 6.02789H15.6085L10.9062 9.4443L12.7023 14.9722L8 11.5558L3.29772 14.9722L5.09383 9.4443L0.391548 6.02789H6.20389L8 0.500031Z" fill="#FC8019"/>
                                                                    </svg>
                                                                    <p class="mb-0 px-2">5.0</p>
                                                                    <svg class="me-2" width="4" height="5" viewBox="0 0 4 5" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <circle cx="2" cy="2.50003" r="2" fill="#C4C4C4"/>
                                                                    </svg>
                                                                    <p class="mb-0">1k+ Reviews</p>
                                                                </div>
                                                                <hr>
                                                            </div>
                                                            <div class="d-flex align-items-center justify-content-between mb-2">
                                                                <span>Delivery Time </span>
                                                                <h6 class="mb-0">10 Min</h6>
                                                            </div>
                                                            <div class="d-flex align-items-center justify-content-between">
                                                                <span>Distance</span>
                                                                <h6 class="mb-0">2.5 Km</h6>
                                                            </div>
                                                            <hr>
                                                            <div class="order-menu">
                                                                <h6 class="font-w600">Order Menu</h6>
                                                                <div class="d-flex align-items-center mb-2">
                                                                    <img class="me-2" src="assets/images/popular-img/review-img/pic-1.jpg" alt="">
                                                                    <div class="order-items">
                                                                        <h6 class="font-w500 text-nowrap mb-0"><a href="javascript:void(0);">Pepperoni Pizza</a></h6>
                                                                        <p class="mb-0">x1</p>
                                                                    </div>
                                                                    <h6 class="text-primary mb-0 ms-auto">+$5.59</h6>
                                                                </div>
                                                                <div class="d-flex align-items-center">
                                                                    <img class="me-2" src="assets/images/popular-img/pic-1.jpg" alt="">
                                                                    <div class="order-items">
                                                                        <h6 class="font-w500 text-nowrap mb-0"><a href="javascript:void(0);">Fish Burger</a></h6>
                                                                        <p class="mb-0">x1</p>
                                                                    </div>
                                                                    <h6 class="text-primary mb-0 ms-auto">+$5.59</h6>
                                                                </div>
                                                                <hr>
                                                                <div class="d-flex align-items-center justify-content-between mb-4">
                                                                    <h4 class="mb-0">Total</h4>
                                                                    <h4 class="mb-0 text-primary">$202.00</h4>
                                                                </div>
                                                                <a href="javascript:void(0);" class="btn btn-outline-primary bgl-primary btn-block">Complete</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-xl-4 col-sm-6 sp15">
                                                    <div class="card h-auto b-hover">
                                                        <div class="card-body px-3">
                                                            <div class="text-center">
                                                                <h4>Order #2</h4>
                                                                <p>Nov 11, 2022 , 18:38 PM</p>
                                                            </div>
                                                            <hr>
                                                            <div>
                                                                <h4>Fast Food Resto</h4>
                                                                <div class="d-flex align-items-center">
                                                                    <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path d="M8 0.500031L9.79611 6.02789H15.6085L10.9062 9.4443L12.7023 14.9722L8 11.5558L3.29772 14.9722L5.09383 9.4443L0.391548 6.02789H6.20389L8 0.500031Z" fill="#FC8019"/>
                                                                    </svg>
                                                                    <p class="mb-0 px-2">5.0</p>
                                                                    <svg class="me-2" width="4" height="5" viewBox="0 0 4 5" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <circle cx="2" cy="2.50003" r="2" fill="#C4C4C4"/>
                                                                    </svg>
                                                                    <p class="mb-0">1k+ Reviews</p>
                                                                </div>
                                                                <hr>
                                                            </div>
                                                            <div class="d-flex align-items-center justify-content-between mb-2">
                                                                <span>Delivery Time </span>
                                                                <h6 class="mb-0">10 Min</h6>
                                                            </div>
                                                            <div class="d-flex align-items-center justify-content-between">
                                                                <span>Distance</span>
                                                                <h6 class="mb-0">2.5 Km</h6>
                                                            </div>
                                                            <hr>
                                                            <div class="order-menu">
                                                                <h6>Order Menu</h6>
                                                                <div class="d-flex align-items-center mb-2">
                                                                    <img class="me-2" src="assets/images/popular-img/review-img/pic-2.jpg" alt="">
                                                                    <div class="order-items">
                                                                        <h6 class="font-w500 text-nowrap mb-0"><a href="javascript:void(0);">Japan Ramen</a></h6>
                                                                        <p class="mb-0">x1</p>
                                                                    </div>
                                                                    <h6 class="text-primary mb-0 ms-auto">+$5.59</h6>
                                                                </div>
                                                                <div class="d-flex align-items-center">
                                                                    <img class="me-2" src="assets/images/popular-img/pic-2.jpg" alt="">
                                                                    <div class="order-items">
                                                                        <h6 class="font-w500 text-nowrap mb-0"><a href="javascript:void(0);">Beef Burger</a></h6>
                                                                        <p class="mb-0">x1</p>
                                                                    </div>
                                                                    <h6 class="text-primary mb-0 ms-auto">+$5.59</h6>
                                                                </div>
                                                                <hr>
                                                                <div class="d-flex align-items-center justify-content-between mb-4">
                                                                    <h4 class="mb-0">Total</h4>
                                                                    <h4 class="mb-0 text-primary">$202.00</h4>
                                                                </div>
                                                                <a href="javascript:void(0);" class="btn btn-outline-primary bgl-primary btn-block">Complete</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="navpills-3" class="tab-pane">
                                    <div class="card h-auto">
                                        <div class="card-body p-2">
                                            <div id="accordion-one" class="accordion style-1">
                                                <div class="accordion-item">
                                                    <div class="accordion-header collapsed" data-bs-toggle="collapse" data-bs-target="#default_collapseOne1">
                                                        <div>
                                                            <h4 class="font-w500 mb-0">Order #1</h4>
                                                            <span>June 1, 2020, 08:22 AM</span>
                                                        </div>
                                                        <button class="btn btn-outline-success bgl-success me-5">Completed</button>
                                                        <span class="accordion-header-indicator"></span>
                                                    </div>
                                                    <div id="default_collapseOne1" class="collapse accordion_body" data-bs-parent="#accordion-one">
                                                        <div class="row">
                                                            <div class="col-xl-12 col-xxl-12 col-sm-12 b-right style-1">
                                                                <div class="order-menu my-4 dlab-space">
                                                                    <h4 class="">Order Menu</h4>
                                                                    <div class="d-flex align-items-center justify-content-xl-center justify-content-lg-start  mb-2">
                                                                        <img class="me-2" src="assets/images/popular-img/review-img/pic-1.jpg" alt="">
                                                                        <div>
                                                                            <h6 class="font-w600 text-nowrap mb-0">Pepperoni Pizza</h6>
                                                                            <p class="mb-0">x1</p>
                                                                        </div>
                                                                        <h6 class="text-primary mb-0 ps-3 ms-auto">+$5.59</h6>
                                                                    </div>
                                                                    <div class="d-flex align-items-center justify-content-xl-center justify-content-lg-start">
                                                                        <img class="me-2" src="assets/images/popular-img/pic-1.jpg" alt="">
                                                                        <div>
                                                                            <h6 class="font-w600 text-nowrap mb-0">Pepperoni Pizza</h6>
                                                                            <p class="mb-0">x1</p>
                                                                        </div>
                                                                        <h6 class="text-primary mb-0 ps-3 ms-auto">+$5.59</h6>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--**********************************
        Content body end
    ***********************************-->

    <!--**********************************
    Footer start
    ***********************************-->
    <?php include 'footer.php'; ?>
    <!--**********************************
        Footer end
    ***********************************-->
</div>


<!--**********************************
    Scripts
***********************************-->

<!-- Required vendors -->
<script src="assets/vendor/global/global.min.js"></script>
<script src="assets/vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<script src="assets/vendor/chart.js/Chart.bundle.min.js"></script>
<script src="assets/vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>


<script src="assets/js/dlabnav-init.js"></script>
<script src="assets/js/custom.js"></script>

</body>

</html>