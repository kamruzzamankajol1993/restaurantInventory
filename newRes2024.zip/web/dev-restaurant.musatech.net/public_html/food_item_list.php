<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content=""/>
    <meta name="author" content=""/>
    <meta name="robots" content=""/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="FoodieScan - Food Restaurant Management Software"/>
    <meta property="og:title" content="FoodieScan - Food Restaurant Management Software"/>
    <meta property="og:description" content="FoodieScan - Food Restaurant Management Software"/>
    <meta property="og:image" content="social-image.png"/>
    <meta name="format-detection" content="telephone=no">

    <!-- PAGE TITLE HERE -->
    <title>FoodieScan</title>

    <!-- FAVICONS ICON -->
    <link rel="shortcut icon" type="image/png" href="assets/images/favicon.png"/>
    <link href="assets/vendor/jquery-nice-select/css/nice-select.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css" rel="stylesheet">

    <!-- Style css -->
    <link href="assets/vendor/swiper/css/swiper-bundle.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
    <link href="assets/vendor/swiper/css/swiper-bundle.min.css" rel="stylesheet">

    <!-- Custom css-->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/mtech.css" rel="stylesheet">


</head>

<body>

<!--*******************
    Preloader start
********************-->
<?php include 'preloader.php'; ?>
<!--*******************
    Preloader end
********************-->

<!--**********************************
    Main wrapper start
***********************************-->

<div id="main-wrapper">

    <!--**********************************
        Nav header start
    ***********************************-->
    <?php include 'top_header.php'; ?>
    <!--**********************************
        Nav header end
    ***********************************-->

    <!--**********************************
    Header start
    ***********************************-->
    <?php include 'top_header_right.php'; ?>
    <!--**********************************
        Header end ti-comment-alt
    ***********************************-->

    <!--**********************************
    Sidebar start
    ***********************************-->
    <?php include 'left_header.php'; ?>
    <!--**********************************
        Sidebar end
    ***********************************-->

    <!--**********************************
        Content body start
    ***********************************-->
    <div class="content-body">
        <div class="container">
            <div class="d-flex align-items-center justify-content-between mb-4">
                <div class="input-group search-area2 style-1">
						<span class="input-group-text p-0"><a href="javascript:void(0)"><svg class="me-1" width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
						<path d="M27.414 24.586L22.337 19.509C23.386 17.928 24 16.035 24 14C24 8.486 19.514 4 14 4C8.486 4 4 8.486 4 14C4 19.514 8.486 24 14 24C16.035 24 17.928 23.386 19.509 22.337L24.586 27.414C25.366 28.195 26.634 28.195 27.414 27.414C28.195 26.633 28.195 25.367 27.414 24.586ZM7 14C7 10.14 10.14 7 14 7C17.86 7 21 10.14 21 14C21 17.86 17.86 21 14 21C10.14 21 7 17.86 7 14Z" fill="#FC8019"></path>
						</svg>
						</a></span>
                    <input type="text" class="form-control p-0" placeholder="What are you looking for...">
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-xl-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="row m-b-30">
                                <div class="col-md-5 col-xxl-12">
                                    <div class="new-arrival-product mb-4 mb-xxl-4 mb-md-0">
                                        <div class="new-arrivals-img-contnent rounded rounded">
                                            <img class="img-fluid" src="assets/images/product/2.jpg" alt="">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-xxl-12">
                                    <div class="new-arrival-content position-relative">
                                        <h4><a href="food_details.php">Fried Rice</a></h4>
                                        <div class="comment-review star-rating">
                                            <span class="review-text">(34 Sold)</span>
                                            <p class="price">$320.00</p>
                                        </div>
                                        <p>Availability: <span class="item"> In stock <i class="fa fa-check-circle text-success"></i></span></p>
                                        <p>Product code: <span class="item">0405689</span> </p>
                                        <p>Parent category: <span class="item">Lee</span></p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 col-xl-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="row m-b-30">
                                <div class="col-md-5 col-xxl-12">
                                    <div class="new-arrival-product mb-4 mb-xxl-4 mb-md-0">
                                        <div class="new-arrivals-img-contnent rounded">
                                            <img class="img-fluid" src="assets/images/product/3.jpg" alt="">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-xxl-12">
                                    <div class="new-arrival-content position-relative">
                                        <h4><a href="food_details.php">Fried Rice</a></h4>
                                        <div class="comment-review star-rating">
                                            <span class="review-text">(34 Sold)</span>
                                            <p class="price">$320.00</p>
                                        </div>
                                        <p>Availability: <span class="item"> In stock <i class="fa fa-check-circle text-success"></i></span></p>
                                        <p>Product code: <span class="item">0405689</span> </p>
                                        <p>Parent category: <span class="item">Lee</span></p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 col-xl-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="row m-b-30">
                                <div class="col-md-5 col-xxl-12">
                                    <div class="new-arrival-product mb-4 mb-xxl-4 mb-md-0">
                                        <div class="new-arrivals-img-contnent rounded">
                                            <img class="img-fluid" src="assets/images/product/4.jpg" alt="">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-xxl-12">
                                    <div class="new-arrival-content position-relative">
                                        <h4><a href="food_details.php">Fried Rice</a></h4>
                                        <div class="comment-review star-rating">
                                            <span class="review-text">(34 Sold)</span>
                                            <p class="price">$320.00</p>
                                        </div>
                                        <p>Availability: <span class="item"> In stock <i class="fa fa-check-circle text-success"></i></span></p>
                                        <p>Product code: <span class="item">0405689</span> </p>
                                        <p>Parent category: <span class="item">Lee</span></p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d-flex align-items-center justify-content-xl-between justify-content-center flex-wrap pagination-bx">
                <div class="mb-sm-0 mb-3 pagination-title">
                    <p class="mb-0"><span>Showing 1-5</span> from <span>100</span> data</p>
                </div>
                <nav>
                    <ul class="pagination pagination-gutter">
                        <li class="page-item page-indicator">
                            <a class="page-link" href="javascript:void(0)">
                                <i class="la la-angle-left"></i></a>
                        </li>
                        <li class="page-item active"><a class="page-link" href="javascript:void(0)">1</a>
                        </li>
                        <li class="page-item"><a class="page-link" href="javascript:void(0)">2</a></li>

                        <li class="page-item"><a class="page-link" href="javascript:void(0)">3</a></li>
                        <li class="page-item page-indicator">
                            <a class="page-link" href="javascript:void(0)">
                                <i class="la la-angle-right"></i></a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
    <!--**********************************
        Content body end
    ***********************************-->

    <!--**********************************
    Footer start
    ***********************************-->
    <?php include 'footer.php'; ?>
    <!--**********************************
        Footer end
    ***********************************-->
</div>


<!--**********************************
    Scripts
***********************************-->

<!-- Required vendors -->
<script src="assets/vendor/global/global.min.js"></script>
<script src="assets/vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<script src="assets/vendor/chart.js/Chart.bundle.min.js"></script>
<script src="assets/vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>

<!-- Apex Chart -->
<script src="assets/vendor/apexchart/apexchart.js"></script>

<script src="assets/vendor/bootstrap-datetimepicker/js/moment.js"></script>
<script src="assets/vendor/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>
<script src="assets/vendor/peity/jquery.peity.min.js"></script>
<script src="assets/vendor/swiper/js/swiper-bundle.min.js"></script>

<!-- Datatable -->
<script src="assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
<script src="assets/js/plugins-init/datatables.init.js"></script>


<!-- Dashboard 1 -->
<script src="assets/js/dashboard/dashboard-2.js"></script>

<script src="assets/js/dlabnav-init.js"></script>
<script src="assets/js/custom.js"></script>
</body>

</html>