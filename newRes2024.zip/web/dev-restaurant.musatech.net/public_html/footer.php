<div class="footer">
    <div class="copyright border-top">
        <p>Copyright © Designed   by <a href="musatechnologyltd.com" target="_blank">MusaTechnology</a> 2022</p>
    </div>
</div>
